CK Icon Font Module
=================

Author
-----------------
Computer Know How, LLC/Seth Engen

Description
-----------------
This module adds icon font support to the CKEditor window.

Installation
-----------------
Drop the 'ckiconfont' folder into your modules/contentbox/modules_user folder within your ContentBox enabled application, or install via the ContentBox Modules ForgeBox link.

Usage
-----------------
Use the icon button in ContentBox CKEditor to add icons to your pages.

Change Log
-----------------
* Version 1.1  - Updated for ContentBox 3
* Version 1.0  - Initial Release